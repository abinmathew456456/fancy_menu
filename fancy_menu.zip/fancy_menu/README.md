

A simple animated  menu list for Flutter, Adjustable radius, colors, text size, Icons and background color.

## Features

![a.gif](doc%2Fa.gif)

![b.jpg](doc%2Fb.jpg)


## Getting started

TODO: List prerequisites and provide or point to information on how to
start using the package.

## Usage

TODO: Include short and useful examples for package users. Add longer examples
to `/example` folder.

```dart
const like = 'sample';
```


# fancy_menu
