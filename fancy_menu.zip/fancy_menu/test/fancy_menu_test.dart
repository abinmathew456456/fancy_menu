import 'package:flutter_test/flutter_test.dart';

import 'package:fancy_menu/fancy_menu.dart';

void main() {
  test('adds one to input values', () {

  });
}
